#include <Wire.h> // necessary, or the application won't build properly
#include <stdio.h>
#include <PCF8583.h>
/*****************************************************************************
 *  read/write serial interface to PCF8583 RTC via I2C interface
 *
 *  Arduino analog input 5 - I2C SCL (PCF8583 pin 6)
 *  Arduino analog input 4 - I2C SDA (PCF8583 pin 5)
 *
 *  You can set the type by sending it YYMMddhhmmss;
 *  the semicolon on the end tells it you're done...
 *
 ******************************************************************************/

int correct_address = 0;
volatile bool tick = false;
int interruption = 19;
PCF8583 p (0xA0);	

void setup(void){
  Serial.begin(9600);
  Serial.print("booting...");
  Serial.println(" done");
  p.clear_timer_flags(true, true);

  pinMode(interruption, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(interruption), isr_pcf8583, FALLING);
  p.set_timer(1); //Un minuto
}

void loop(void){
  if(Serial.available() > 0){
       p.year= (byte) ((Serial.read() - 48) *10 +  (Serial.read() - 48)) + 2000;
       p.month = (byte) ((Serial.read() - 48) *10 +  (Serial.read() - 48));
       p.day = (byte) ((Serial.read() - 48) *10 +  (Serial.read() - 48));
       p.hour  = (byte) ((Serial.read() - 48) *10 +  (Serial.read() - 48));
       p.minute = (byte) ((Serial.read() - 48) *10 +  (Serial.read() - 48));
       p.second = (byte) ((Serial.read() - 48) * 10 + (Serial.read() - 48)); // Use of (byte) type casting and ascii math to achieve result.  

       if(Serial.read() == ';'){
         Serial.println("setting date");
	       p.set_time();
       }
  }

  if (tick) { 
  	tick = false; // -> aquí haces tu "log"
    Serial.println("Interrumpido en la interrupción");
    p.clear_timer_flags(true, true);
    p.set_timer(1); //Un minuto
  }

  p.get_time();
  char time[50];
  sprintf(time, "%02d/%02d/%02d %02d:%02d:%02d",
	  p.year, p.month, p.day, p.hour, p.minute, p.second);
  Serial.println(time);
	
	
  delay(5000);
}



void isr_pcf8583() {
  tick = true;
  // Limpia la(s) flag(s) que haya puesto el chip
}






